#!/usr/bin/env python3
# Copyright 2025-2026 Joseph Brendler
# SPDX-License-Identifier: GPL-3.0-or-later
"""Headless CLI/planner tests: disposable config/header, forbidden-operation spies.

The verbosity helper is read from the installed header, not reimplemented.
A separate smoke test exercises the complete installed UI/header with logging
and the root gate disabled only in a temporary client copy.
"""
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
HEADER = Path('/usr/sbin/script_header_joetoo')


class PlannerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        (self.folder / 'libexec').mkdir()
        shutil.copyfile(ROOT / 'libexec/joetoo-kwin-plan-functions',
                        self.folder / 'libexec/joetoo-kwin-plan-functions')
        self.client = self.folder / 'joetoo-kwin'
        self.config = self.folder / 'layout.conf'
        self.calls = self.folder / 'calls'
        self.env = {**os.environ, 'TRACE': str(self.calls), 'verbosity': '5',
                    'INTERACTIVE': '', 'QUIET': '', 'DEBUG': '', 'LOGGING': '',
                    'TERM': 'dumb', 'JOETOO_HEADER_DIR': '/usr/sbin',
                    'PATH': str(self.folder) + os.pathsep + os.environ['PATH']}
        for program in ('qdbus6', 'konsole', 'ssh', 'ssh_wrapper', 'vncviewer', 'btop'):
            spy = self.folder / program
            spy.write_text('#!/bin/sh\nprintf "%s\\n" "$0 $*" >> "$TRACE"\nexit 99\n')
            spy.chmod(0o755)
        # UI spies verify stage order and effective varlist without depending on
        # terminal width or emoji availability. Use the actual verbosity helper.
        header_source = HEADER.read_text()
        start = header_source.index('_pc_action_verbosity()')
        end = header_source.index('\n_pc_action_quiet()', start)
        self.mock_header = self.folder / 'header'
        self.mock_header.write_text(r'''
TRUE=0; FALSE=''; notice=5; info=6; debug=7; err=3
BCon=''; BGon=''; Boff=''
checknotroot() { :; }
j_msg() {
    local level=5 arg
    for arg in "$@"; do [[ $arg =~ ^-([0-7])$ ]] && level=${BASH_REMATCH[1]}; done
    if (( verbosity >= level )); then printf '%s\n' "${*: -1}"; fi
    return 0
}
isint() { [[ $1 =~ ^-?[0-9]+$ ]]; }
handle_result() { return "${REPORT_RC:-0}"; }
decode_right_status() { printf 'DECODE:%s\n' "$1"; }
show_config() {
    local name
    printf 'CONFIG\n'
    for name in $varlist; do printf '%s=%s\n' "$name" "${!name}"; done
}
''' + header_source[start:end])
        self.client.write_text((ROOT / 'joetoo-kwin').read_text().replace(
            'source /usr/sbin/script_header_joetoo',
            'source "' + str(self.mock_header) + '"', 1))
        self.write_config()

    def write_config(self, records=None, extra=''):
        if records is None:
            records = ['1|konsole|ssh|unreachable.invalid', '1|konsole|local|btop']
        # Test inputs are literal trusted Bash strings; no user input is evaluated.
        self.config.write_text('screen_width=1920\nscreen_height=1080\n' +
                               'desktop_session_list=(\n' +
                               '\n'.join("'" + record + "'" for record in records) +
                               '\n)\n' + extra + '\n')

    def run_cli(self, *args, expected=0):
        result = subprocess.run(['bash', str(self.client), *args], env=self.env,
                                text=True, capture_output=True, timeout=20)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        # Every planner/error test asserts the absence of D-Bus, GUI and transport.
        self.assertFalse(self.calls.exists(), self.calls.read_text() if self.calls.exists() else '')
        return result.stdout

    def plan(self, *args, expected=0):
        return self.run_cli('-c', '-f', str(self.config), *args, expected=expected)

    @staticmethod
    def rows(output):
        return [line.split() for line in output.splitlines()
                if re.match(r'^\d+ \d+ ', line)]

    def test_default_budget_and_effective_config_before_plan(self):
        output = self.plan()
        self.assertLess(output.index('CONFIG'), output.index('DRY RUN'))
        self.assertIn('terminal_width_percent=87', output)
        self.assertIn('not autodetected', output)
        self.assertEqual([row[-4:] for row in self.rows(output)],
                         [['19', '54', '816', '918'], ['873', '54', '816', '918']])

    def test_config_overrides_defaults_then_cli_overrides_config(self):
        self.write_config(extra='terminal_width_percent=80\nterminal_gap_percent=4\nverbosity=6')
        output = self.plan('-q')
        self.assertIn('verbosity=5', output)
        self.assertIn('terminal_width_percent=80', output)
        self.assertEqual([row[-4:] for row in self.rows(output)],
                         [['19', '54', '730', '918'], ['825', '54', '730', '918']])

    def test_common_option_order_and_clusters(self):
        output = self.run_cli('-vq', '-f', str(self.config), '-c')
        self.assertIn('verbosity=5', output)
        self.assertIn('verbosity=7', self.plan('-vv'))
        self.assertIn('verbosity=3', self.plan('-qq'))
        self.assertIn('verbosity=5', self.plan('-v', '-q'))
        self.plan('--')

    def test_verbosity_clamps_and_interactive_floor(self):
        self.assertIn('verbosity=7', self.plan('-vvvvvv'))
        self.assertIn('verbosity=0', self.plan('-qqqqqqqq'))
        self.env['INTERACTIVE'] = '0'
        self.assertIn('verbosity=5', self.plan('-qqqqqqqq'))

    def test_one_three_four_and_alternate_display(self):
        for count in (1, 3, 4):
            with self.subTest(count=count):
                self.write_config(['1|konsole|direct|'] * count,
                                  'screen_width=2560\nscreen_height=1440')
                rows = self.rows(self.plan())
                self.assertEqual(len(rows), count)
                rects = [list(map(int, row[-4:])) for row in rows]
                for x, y, w, h in rects:
                    self.assertGreater(w, 0); self.assertGreater(h, 0)
                    self.assertLessEqual(x + w, 2560)
                    self.assertLessEqual(y + h, 1440)
                columns = 2 if count == 4 else count
                self.assertLessEqual(columns * rects[0][2] + (columns - 1) * 51, 2227)
                if count == 4:
                    self.assertEqual(rects[0][0], rects[2][0])
                    self.assertGreater(rects[2][1], rects[0][1] + rects[0][3])

    def test_graphical_windows_do_not_consume_terminal_slots(self):
        self.write_config(['1|konsole|ssh|unreachable.invalid', '1|vncviewer|via-ssh|host',
                           '1|konsole|direct|', '2|konsole|direct|'])
        rows = self.rows(self.plan())
        self.assertEqual([row[1] for row in rows], ['1', '2', '3', '1'])
        self.assertEqual(rows[0][-4:], ['19', '54', '816', '918'])
        self.assertEqual(rows[2][-4:], ['873', '54', '816', '918'])
        self.assertEqual(rows[1][5], 'underlay-proposed')
        self.assertEqual(rows[3][-2:], ['1670', '918'])

    def test_custom_offsets_height_and_row_gutters(self):
        self.write_config(['1|konsole|direct|'] * 4,
                          'terminal_left_percent=2\nterminal_top_percent=10\n'
                          'terminal_height_percent=80\nterminal_row_gap_percent=4')
        rows = self.rows(self.plan())
        self.assertEqual(rows[0][-4:], ['38', '108', '816', '410'])
        self.assertEqual(rows[2][-4:], ['38', '561', '816', '410'])

    def test_invalid_geometry_inputs(self):
        for extra in ('screen_width=0', 'screen_height=32769', 'desktop_limit=257',
                      'terminal_width_percent=0', 'terminal_height_percent=101',
                      'terminal_gap_percent=99', 'terminal_row_gap_percent=99',
                      'terminal_top_percent=20', 'terminal_left_percent=20',
                      'graphical_width_percent=99', 'graphical_top_percent=20',
                      'screen_width=999999999999999999999999999999999',
                      'screen_width=01920', 'screen_width="1+2"', 'unset screen_width'):
            with self.subTest(extra=extra):
                self.write_config(['1|konsole|direct|'] * 4, extra)
                self.plan(expected=2)

    def test_missing_explicit_dimensions(self):
        self.config.write_text("desktop_session_list=('1|konsole|direct|')\n")
        self.plan(expected=2)

    def test_invalid_records_and_terminal_limit(self):
        for records in ([], ['1|konsole|direct|'] * 5, ['0|konsole|direct|'],
                        ['257|konsole|direct|'], ['01|konsole|direct|'],
                        ['1|konsole|ssh|'], ['1|konsole|bad|host'],
                        ['1|konsole|direct'], ['1|konsole|direct||'],
                        ['1|/usr/bin/konsole|direct|'], ['1|konsole|local|a\nb']):
            with self.subTest(records=records):
                self.write_config(records)
                self.plan(expected=2)

    def test_wrong_array_types(self):
        for definition in ('desktop_session_list=scalar', 'declare -A desktop_session_list=([a]=b)'):
            self.config.write_text('screen_width=1920\nscreen_height=1080\n'
                                   'unset desktop_session_list\n' + definition + '\n')
            self.plan(expected=2)

    def test_missing_and_failed_config(self):
        self.config.unlink()
        self.plan(expected=2)
        self.config.write_text('return 1\n')
        self.plan(expected=2)

    def test_bad_cli_and_conflicting_operations(self):
        for args in (('-c', '-f'), ('-c', '-c'), ('-c', '-o'), ('-c', 'extra'),
                     ('-c', '--unknown'), ('-v',), ('-f', str(self.config), '-m', '1', '2', '3', '4', '5')):
            with self.subTest(args=args):
                self.run_cli(*args, expected=2)
        self.run_cli('-o', '-f', str(self.config), expected=2)

    def test_reporting_fault_is_not_silent_success(self):
        self.env['REPORT_RC'] = '2'
        self.assertIn('result reporting failed', self.plan(expected=1))

    def test_selected_config_sourced_once_and_default_path_used(self):
        reads = self.folder / 'config-reads'
        self.write_config(extra=f'printf "read\\n" >> "{reads}"')
        self.client.write_text(self.client.read_text().replace(
            'config=/etc/joetoo-kwin/joetoo-kwin.conf', f'config="{self.config}"'))
        self.run_cli('-c')
        self.assertEqual(reads.read_text(), 'read\n')

    def test_move_grammar_preserves_negative_coordinates_without_loading_config(self):
        # Replace only the action in a temporary client; never move a real window.
        self.client.write_text(self.client.read_text().replace(
            '#-----[ main script ]',
            'move_active_window() { printf "MOVE:%s\\n" "$*"; }\n#-----[ main script ]'))
        self.config.unlink()
        for args in (('-m', '1', '-19', '-54', '816', '918'),
                     ('-v', '-m', '1', '-19', '-54', '816', '918'),
                     ('move', '1', '-19', '-54', '816', '918')):
            self.assertIn('MOVE:1 -19 -54 816 918', self.run_cli(*args))
        self.run_cli('-m', '1', '2', '3', expected=2)

    def test_installed_header_config_and_color_smoke(self):
        # No host operations: source the real header with logging off, then
        # override only the root check in this disposable client copy.
        self.client.write_text((ROOT / 'joetoo-kwin').read_text().replace(
            'source /usr/sbin/script_header_joetoo',
            'source /usr/sbin/script_header_joetoo\nchecknotroot() { :; }', 1))
        output = self.plan()
        plain = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', output)
        self.assertIn('DRY RUN: [2]', plain)
        self.assertIn('terminal_width_percent', plain)
        self.assertIn('816', plain)
