# joetoo-kwin documentation-only review bundle

**Based on GitHub main** `ee839a0a5a5e5dbdee6c3d1b221812179145b19f` (October 27, 2026).

No `AGENTS.md` files are touched. Do not commit or push this draft before review.

## Proposed scope

1. `ARCHITECTURE.md`: title clarifies version 1 requirements; move historical POC/test
   results and fastfetch-style platform inventories out of product design;
   preserve D-Bus contracts; fix Markdown table/header numbering;
   remove draft inspection notes and duplicate collaboration procedures.
2. Project `README.md`: short orientation, platform matrix, progress/validation
   summaries, links to PR #16/#17, and agreed 1.4a–1.4d plan.
3. Move `STEP1_3B_PROBE.md` unchanged to `archive/STEP1_3B_PROBE.md`;
   add it to `archive/README.md`.

The archived file is intentionally a historical snapshot. Do not interpret
its then-pending experiments as currently outstanding.

## Generate and inspect the real unified diff

Download `joetoo-kwin-doc-review.py`, then on gmki91 (not from a protected repo):

```bash
cd ~/joetoo-ai
git switch main
git pull --ff-only origin main
git status -sb
python3 ~/Downloads/joetoo-kwin-doc-review.py --repo "$PWD"     --output "$HOME/Downloads/joetoo-kwin-doc-review.patch"
git apply --check "$HOME/Downloads/joetoo-kwin-doc-review.patch"
git apply --stat "$HOME/Downloads/joetoo-kwin-doc-review.patch"
less "$HOME/Downloads/joetoo-kwin-doc-review.patch"
```

The generator copies only the four relevant source documents into a throwaway
local Git repository, calculates the patch there, then deletes the temporary
directory. It does **not** alter the real joetoo-ai checkout.

Only when approved:

```bash
git switch -c task/joetoo-kwin-documentation-boundaries
git apply "$HOME/Downloads/joetoo-kwin-doc-review.patch"
git diff --check
git diff --stat
git diff --find-renames=90%
```

Commit/push/PR review needs a separate authorization; do not edit the protected
joetoo or joetoo-upstream repositories.

## Known limitation of this delivery

Current GitHub files were inspected using the connected GitHub source tools,
but a Git checkout is not available inside the assistant's container. The
generator's exact replacements were syntax-checked and exercised against
a synthetic matching fixture, **not** run against the real current checkout.
`git apply --check` on gmki91 is the first real-base validation gate.
