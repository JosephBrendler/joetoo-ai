# Step 1.3b.1 — diagnostic launch correlation (review candidate)

The aim is to determine which observed KWin UUID belongs to a particular
program launch, regardless of whether it opens a Konsole, another local GUI,
or a local terminal for SSH/VNC. The target host, if any, is not itself a KWin
window identity. This increment is read-only and **does not** grant managed
ownership, request placement or change the legacy `test-launch` contract.

## Proposed native experiments (ordinary Plasma user, X11 and Wayland)

Run the Python and JS regression tests before replacing the POC broker. The
updated broker adds `BeginCorrelation`, `SetCorrelationPid`, and
`PollCorrelation`, each on `org.joetoo.KWinBridge`. The resident JS does not
need replacement in this increment because Steps 1.3a–1.3a.2 already report
window UUIDs, PIDs, titles, and lifecycle changes.

For a disposable new Konsole, while the updated broker is running:

```bash
cd ~/joetoo-ai/workspace/projects/joetoo-kwin
bash tools/joetoo-kwin-correlation-probe konsole -- konsole --separate
```

The probe arms the request before starting the program, records Bash's `$!`,
and polls for newly observed windows. **Only one new, exact PID match** after a
short settle interval returns `MATCHED` and its UUID. Two new same-PID
windows give `AMBIGUOUS`; a changed-only event, unmatched PID, prior UUID,
missing inventory, or resident restart must never be silently adopted.

The optional syntax `--title-token TOKEN` records title matches for diagnosis;
**title alone is not proof**. If a program forks, the KWin PID may differ
from the shell PID, yielding a deliberate `TIMEOUT` with possible title hints.
That result is valuable evidence for designing a stronger transaction token
in a later Step 1.3b increment.

The tool does not terminate the launched process on completion, failure, or
timeout, and it does not change placement. Close disposable windows normally.
Run same-class interference tests and then repeat on both backends. The
existing `test-launch` retains its historical class-only placement POC and
must not be mistaken for a safe managed-window correlation implementation.

## Headless checks

```bash
python3 -m unittest discover -s tests -p 'test_*.py' -v
node --test tests/test_step1_3a.js
bash -n tools/joetoo-kwin-correlation-probe
```

Native PID/title correspondence, timeout behavior, and process independence
remain subject to human desktop validation. This is not the Step 1.4 registry.
