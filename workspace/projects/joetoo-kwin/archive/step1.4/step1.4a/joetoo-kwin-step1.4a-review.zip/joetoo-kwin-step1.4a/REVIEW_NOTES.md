# Step 1.4a draft — review handoff

**Based on inspected GitHub main:** `93b68c306f17a93dfe31af4dfe102ff92c5f4922` (October 27, 2026).

Draft scope: **two new files only**. `libexec/joetoo_kwin_registry.py` and
`tests/test_step1_4a_registry.py` implement and test an isolated in-memory
model. No broker event integration, D-Bus interface, GUI launch, checkpoint,
close, or deployment changes are included.

## Validation already performed in drafting environment

- 14 new headless tests passed.
- `compileall` completed.
- `git diff --cached --check` completed.
- `git apply --check` succeeded on a fresh scratch repository.
- Applying the patch and rerunning 14 new tests in the scratch repository succeeded.
- **Existing joetoo-kwin 74 Python / 4 JavaScript regression tests were not rerun**
  in this drafting environment (the actual joetoo-ai checkout is not locally available).

## Inspect and apply on gmki91 or q552u01

```bash
cd ~/joetoo-ai
git switch main
git pull --ff-only origin main
git status -sb
# Only if you want a new review branch and the checkout is clean:
git switch -c task/joetoo-kwin-step1.4a-registry-contract
# Put the downloaded patch at ~/Downloads/joetoo-kwin-step1.4a.patch
git apply --check "$HOME/Downloads/joetoo-kwin-step1.4a.patch"
git apply "$HOME/Downloads/joetoo-kwin-step1.4a.patch"
git diff --check
git diff --stat
cd workspace/projects/joetoo-kwin
python3 -m unittest discover -s tests -p 'test_*.py' -v
node --test tests/test_step1_3a.js
```

Do **not** commit until you review the code and approve the contract.

## Safety boundaries for 1.4b

`WindowRegistry.register_match()` accepts an internal broker-issued correlation result;
it does not authenticate a D-Bus sender. Broker integration **must** bind a
`MATCHED` result to an actual broker-associated launch, use the broker's own
synchronized `observed_windows` inventory, and never expose arbitrary register
operations on the public bus. This is essential before treating records as
managed, and is distinct from stronger close authorization required by Step 1.6.

## Editorial correction (not part of this two-file patch)

In the project README, the Step 1.4d table row currently contains text that
belongs below the table. Replace its outcome with:

`Validate representative multiwindow scenarios with mocks, then native X11 and Wayland tests`

Below the table, retain the contract note:

`The Step 1.4a registry contract is defined in ARCHITECTURE.md §§4–5.
Exact internal representations and state transitions are finalized during
Step 1.4a; implementation and native validation results are recorded here
at milestone completion.`

Also replace the immediately following sentence claiming the full registry
schema remains undecided: only the new D-Bus method names and detailed
future interfaces remain pending approval. This editorial fix can be made
by maintainer in GitHub web UI or bundled with a later milestone handoff.
