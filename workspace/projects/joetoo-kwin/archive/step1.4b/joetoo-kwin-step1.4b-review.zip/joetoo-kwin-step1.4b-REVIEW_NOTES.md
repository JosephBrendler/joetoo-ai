# Step 1.4b — broker registration/reconciliation candidate

Baseline: `joetoo-ai` `main` `8d6e124ca875102e8299ca768b6c73a2c64b4dc8` (merged Step 1.4a).

This is a **draft for maintainer review**, not an installed POC or a committed/pushed PR.

## Files changed

- `workspace/projects/joetoo-kwin/libexec/joetoo-kwind` — instantiate `WindowRegistry`; add private broker-managed launch/correlation/registration methods; reuse the existing diagnostic correlation evaluator without promoting public `PollCorrelation`; reconcile registered UUIDs on window events and inventory refreshes, leaving missing/uncertain records unadopted.
- `workspace/projects/joetoo-kwin/tools/joetoo-kwind-install-poc` — add the already-accepted registry module to user-owned install/check/update/backup, because the broker now imports the sibling Python module.
- `workspace/projects/joetoo-kwin/tests/test_step1_4b_broker.py` — headless tests for managed registration, independent UUIDs, public diagnostic isolation, rejected duplicates, same/new resident inventory, matching-PID evidence, missing/uncertain handling, installer dependency, broker restart behavior.

`libexec/joetoo_kwin_registry.py` and the Step 1.4a tests remain unmodified.

## Scope boundary

The private methods `_begin_managed_launch`, `_set_managed_launch_pid`, and `_poll_managed_launch` are **not** D-Bus methods. No installed CLI path invokes them yet. Therefore the live CLI cannot enroll windows with this patch alone. This is broker-side wiring and headless integration only; authorizing a caller to perform a managed launch requires a later, separately reviewed launch/ownership handshake. The public diagnostic `BeginCorrelation`, `SetCorrelationPid`, and `PollCorrelation` cannot grant managed status. No close, persistence, restored registry, session monitor, or new read-only D-Bus methods are included.

The observation D-Bus sender has not been authenticated as the KWin resident, so records must **not** authorize destructive actions; this remains a Step 1.6 safety prerequisite.

## Scratch validation performed

- Verified the reconstructed **original** `joetoo-kwind` Git blob equals `b1f4d103b9ccd3cb4e3eaf39397e1a3d082b65b7` from the accepted baseline.
- Verified the reconstructed **original** installer blob equals `8a6e242573efbe2ffabedb54ff842d397f6af5f6`.
- 67 Python tests passed in the scratch workspace (baseline subset, including 15 new Step 1.4b tests).
- 4 JavaScript tests passed.
- Python compilation (`py_compile`), `sh -n` installer check, `git diff --check`, and clean `git apply --check` / application onto a fresh reconstructed accepted source checkout passed.

The full `gmki91` test inventory and native X11/Wayland tests were **not** run in this sandbox. `gmki91` previously reported 88 Python tests before this patch. The new 1.4b tests raise the expected local total to 103, provided the remainder of the test suite is unchanged.

## Maintainer review / local application

From your clean `joetoo-ai` checkout (the ZIP has the exact patch file):

```bash
cd ~/joetoo-ai
git switch main
git pull --ff-only origin main
git switch -c task/joetoo-kwin-step1.4b-registration-reconciliation
# unzip the ZIP into ~/Downloads or copy the patch there first
git apply --check ~/Downloads/joetoo-kwin-step1.4b-registration-reconciliation.patch
git apply ~/Downloads/joetoo-kwin-step1.4b-registration-reconciliation.patch
git diff --check
git status -sb
git diff --stat
cd workspace/projects/joetoo-kwin
python3 -m unittest discover -s tests -p 'test_*.py' -v
node --test tests/test_step1_3a.js
python3 -m py_compile libexec/joetoo-kwind libexec/joetoo_kwin_registry.py tests/test_step1_4b_broker.py
sh -n tools/joetoo-kwind-install-poc
```

The POC installer will now report an existing installation as outdated until the registry module is installed beside the updated broker; do not update a running service as part of headless testing.

Do not commit, push, create a PR, merge, or deploy solely because this review bundle exists. Final publication is a separate maintainer decision.
