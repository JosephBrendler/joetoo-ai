# Step 1.4d: managed-launch connection — candidate, not published

Source baseline: `JosephBrendler/joetoo-ai`, task branch
`task/joetoo-kwin-step1.4d-multiwindow-validation`, WIP commit `ddea39d`.

## Scope

Adds an experimental broker-owned managed launch-intent transaction. Bash
continues to spawn each Konsole independently; the broker receives its PID and
performs the existing synchronized new-window/PID correlation before assigning
`managed_id` to the observed UUID. Public D-Bus callers never submit a UUID
or managed ID for registration. Placement and registration have separate request
IDs and distinct results. Retains `test-launch`, the ordinary production `-o`
stub, and the maintainer's installer backup-suffix change.

### New broker D-Bus methods

* `SubmitManagedLaunch(class, desktop, slot, x, y, width, height)` -> JSON string
  containing placement_request_id and registration_request_id.
* `SetManagedLaunchPid(registration_request_id, child_pid)` -> no output.
* `PollManagedLaunch(registration_request_id)` -> JSON string with pending,
  registered, timeout, ambiguous, or failure, including UUID and managed ID
  **only if privately registered by the broker**.

`test-multi-launch` uses the new method sequence, still with four local
Konsoles on two desktops and fixed 1920x1080 test geometry.

## How to generate an exact patch locally

1. Confirm the WIP commit is checked out on its task branch with no newer edits
   to the three target source files (the generator checks each exact Git blob).
2. From anywhere inside the joetoo-ai checkout, run the generator and redirect
   stdout to a patch path of your choice. It performs **no writes to the repo**.
3. Review the patch and `git apply --check` before applying. The tests are
   included as new files by the generated patch.
4. Run `python3 -m unittest discover -s tests -p 'test_*.py' -v`,
   `node --test tests/test_step1_3a.js`, `bash -n joetoo-kwin` and
   `git diff --check` from `workspace/projects/joetoo-kwin/`.
5. Before a native test, stop user OpenRC broker, run the existing POC installer
   `--update`, and start broker; this installs the changed source. Verify
   `RegistryStatus`/`ListManaged` after launch. Run native tests on X11 and
   Wayland separately. Do not close unrelated existing windows.

Commands in this document deliberately do not form executable code blocks.

## Validation completed here

* Source baseline target blob SHAs retrieved from GitHub at `ddea39d`.
* Exact-fragment replacement generator: syntax and synthetic-Git apply check.
* Three headless Bash CLI contract tests in an isolated synthetic harness:
  passed.
* Python broker-method fragment: parsed as Python syntax.
* Added Python broker integration tests: created but **not run here**.
* Whole repository Python/Node suite: **not run here**.
* Native X11/Wayland managed-registration tests: **not run here**.

## Important design limitations

The three new launch-intent methods are *public D-Bus API* on the current
user session bus, even though the ultimate UUID registration remains a private
broker decision. Treat these as experimental; before production close (-d/-x),
review caller authorization / PID provenance and the appropriate IPC boundary.
The existing class-qualified placement path may select a different same-class
window under concurrent launches; only exact PID/UUID correlation establishes
managed ownership. The registry's `placement` field is not yet updated by this
new experimental bridge, so don't infer its state from placement output.

No commit, push, PR, merge, deployment or host administration is performed by
this bundle.
