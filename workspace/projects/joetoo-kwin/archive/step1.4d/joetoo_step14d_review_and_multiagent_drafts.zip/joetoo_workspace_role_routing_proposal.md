# Proposed addition to `workspace/AGENTS.md` — NOT ACTIVE

> Maintainer-review candidate only. Do not append to the governing file without explicit maintainer approval. Preserve and reconcile the maintainer's existing local edits; this proposal has not inspected those uncommitted edits.

## Subordinate agent roles and active handoffs

All collaborators follow the repository-root, workspace and applicable project `AGENTS.md` hierarchy. For local implementation agents, including Codex CLI, additionally load and follow `workspace/LOCAL_AGENTS.md`. For cloud collaboration agents, including ChatGPT in that role, additionally load and follow `workspace/CLOUD_AGENTS.md`. A role file marked **DRAFT / NOT ACTIVE** is background material only, not an enforceable instruction or an authorization grant. Role-specific documents are subordinate to governing policy and maintainer-approved task scope.

At the beginning of every substantive actionable turn, re-read the applicable `AGENTS.md` hierarchy, the active role instructions and the current active-task handoff. Reconcile changed instructions, current branch/commit and handoff status before acting. Read only relevant supporting skills/source, and do not repeat unchanged boilerplate in reports. If files are inaccessible, state that fact; neither cached memory nor a prior chat proves the current state.

The **maintainer owns task designation and authorization**. Each active task must identify its canonical handoff location (for example, a task-specific file under the relevant project), target branch/base, permitted file edits and tool operations, acceptance tests, prohibited actions, stop conditions and next responsible actor. Do not infer that a draft task handoff or role document grants permission. Where a task identifier resolves ambiguously or to no approved handoff, perform only read-only orientation pending clarification.

The normal relay is **cloud collaborator → maintainer authorization → local collaborator**, and **local collaborator → maintainer review → cloud collaborator**. A maintainer may explicitly authorize bounded multi-iteration agent-to-agent exchanges with per-iteration progress reports, while reserving publication, deployment, protected-repository and scope-expansion decisions. A handoff file stores state; an authorized orchestration tool or the maintainer must actually initiate each subsequent agent invocation.
